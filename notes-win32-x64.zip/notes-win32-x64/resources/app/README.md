# swat_notes

Practice app in electron...

This app provides a quick and easy method to create notes for T2 reps.

vuejs code works in jsfiddle, but still not sure how to get my vue to be recognized in electronjs.  notes.js holds the vue function, but for whatever reason it is not initiated properly.